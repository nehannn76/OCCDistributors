﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OCCDist
{
    public partial class MainSchedeNonRinnovate : System.Web.UI.Page
    {
        private static string SIEMENS_GID = "";
        private Utilities ut = new Utilities();
        private static long lidSchedaErrore;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SIEMENS_GID = (string)Session["SIEMENS_GID"];
                //ViewState["strSortExpression"] = (string)Session["strSortExpression"];
                ViewState["strSortExpression"] = "id";
                ViewState["strSortDirection"] = "Desc";
                ViewState["imgSortDir"] = @"Images\SortDown.jpg";
                ViewState["idScheda"] = (string)Session["idScheda"];
                ViewState["MA"] = (string)Session["MA"];
                ViewState["stato"] = (string)Session["stato"];
                ViewState["U1Nominativo"] = (string)Session["U1Nominativo"];
                ViewState["U2Nominativo"] = (string)Session["U2Nominativo"];
                ViewState["URNominativo"] = (string)Session["URNominativo"];
                ViewState["RivRagioneSociale"] = (string)Session["RivRagioneSociale"];
                ViewState["CliRagioneSociale"] = (string)Session["CliRagioneSociale"];
                ViewState["Validita_Da"] = (string)Session["Validita_Da"];
                ViewState["Validita_A"] = (string)Session["Validita_A"];
                BindGrid((string)ViewState["strSortExpression"], (string)ViewState["strSortDirection"]);
            }
        }
        void BindGrid(string SortColumn, string SortDirection)
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                string SIEMENS_GID = (string)Session["SIEMENS_GID"];

                string strMinAnnoFiscale = (string)ViewState["Validita_Da"];
                string strMaxAnnoFiscale = (string)ViewState["Validita_A"];

                // SE E' LA PRIMA VOLTA CHE CARICA LA PAGINA
                // purtroppo  non si può utilizzare IsPostBack perchè la Gridview non è stata
                // ancora inizializzata
                if ((string)ViewState["Validita_Da"] == "")
                {
                    var qryMinMaxAnnoFiscale = context.SelMinMaxAnnoFiscale().ToList();
                    // il filtro di inizio validità non è più impostato all'inizio dell'anno fiscale
                    //strMinAnnoFiscale = qryMinMaxAnnoFiscale[0].Min_Periodo_Mese;
                    strMaxAnnoFiscale = qryMinMaxAnnoFiscale[0].Max_Periodo_Mese;

                    var qryMinPeriodi = context.AnnoFiscale_Periodi
                                        .Select(AF => new { AF.Periodo_Mese, AF.Codice_AnnoFiscale })
                                        .OrderBy(AF => AF.Codice_AnnoFiscale)
                                        .FirstOrDefault();

                    strMinAnnoFiscale = qryMinPeriodi.Periodo_Mese;
                }

                long lidScheda = 0;
                if ((string)ViewState["idScheda"] != "")
                    lidScheda = Convert.ToInt32((string)ViewState["idScheda"]);

                var qrySelMainSchede = context.SelMainSchedeNonRinnovate(SIEMENS_GID,
                                                            strMinAnnoFiscale,
                                                            strMaxAnnoFiscale,
                                                            lidScheda,
                                                            (string)ViewState["MA"],
                                                            (string)ViewState["stato"],
                                                            (string)ViewState["U1Nominativo"],
                                                            (string)ViewState["U2Nominativo"],
                                                            (string)ViewState["URNominativo"],
                                                            (string)ViewState["RivRagioneSociale"],
                                                            (string)ViewState["CliRagioneSociale"],
                                                            SortColumn,
                                                            SortDirection).ToList();
                GVSchede.DataSource = qrySelMainSchede;
                GVSchede.DataBind();

                // Colonna MacroArea
                DropDownList ddlMA = (DropDownList)GVSchede.HeaderRow.FindControl("ddlMA");
                ddlMA.DataSource = context.GetMacroaree(SIEMENS_GID).ToList();
                ddlMA.DataBind();
                // inserisce un item blank per cancellare il filtro
                ddlMA.Items.Insert(0, new ListItem(String.Empty, String.Empty));

                // Colonna Stato
                DropDownList ddlstatischede = (DropDownList)GVSchede.HeaderRow.FindControl("ddlStato");
                ddlstatischede.DataSource = (from S in context.Stati_Schede select S.Codice).ToList();
                ddlstatischede.DataBind();
                // inserisce un item blank per cancellare il filtro
                ddlstatischede.Items.Insert(0, new ListItem(String.Empty, String.Empty));

                // Colonne Validità
                DropDownList ddlValidita_Da = (DropDownList)GVSchede.HeaderRow.FindControl("ddlValidita_Da");
                DropDownList ddlValidita_A = (DropDownList)GVSchede.HeaderRow.FindControl("ddlValidita_A");
                var queryPeriodi = (from P in context.AnnoFiscale_Periodi select P.Periodo_Mese);
                ddlValidita_Da.DataSource = queryPeriodi.ToList();
                ddlValidita_A.DataSource = queryPeriodi.ToList();
                // SE E' LA PRIMA VOLTA CHE CARICA LA PAGINA
                // purtroppo  non si può utilizzare IsPostBack perchè la Gridview non è stata
                // ancora inizializzata
                if ((string)ViewState["Validita_Da"] == "")
                {
                    // il filtro di inizio validità non è più impostato all'inizio dell'anno fiscale
                    //ddlValidita_Da.SelectedValue = strMinAnnoFiscale;
                    ddlValidita_A.SelectedValue = strMaxAnnoFiscale;
                }
                ddlValidita_Da.DataBind();
                ddlValidita_A.DataBind();

                RipristinaFiltri();
            }
        }
        protected void RipristinaFiltri()
        {
            // Rimuove tutte le immagini sort
            Image imgSortlnkid = (Image)GVSchede.HeaderRow.FindControl("imgSortlnkid");
            imgSortlnkid.ImageUrl = "";
            Image imgSortlnkMA = (Image)GVSchede.HeaderRow.FindControl("imgSortlnkMA");
            imgSortlnkMA.ImageUrl = "";
            Image imgSortlnkStato = (Image)GVSchede.HeaderRow.FindControl("imgSortlnkStato");
            imgSortlnkStato.ImageUrl = "";
            Image imgSortlblU1Nominativo = (Image)GVSchede.HeaderRow.FindControl("imgSortlblU1Nominativo");
            imgSortlblU1Nominativo.ImageUrl = "";
            Image imgSortlblU2Nominativo = (Image)GVSchede.HeaderRow.FindControl("imgSortlblU2Nominativo");
            imgSortlblU2Nominativo.ImageUrl = "";
            Image imgSortlblURNominativo = (Image)GVSchede.HeaderRow.FindControl("imgSortlblURNominativo");
            imgSortlblURNominativo.ImageUrl = "";
            Image imgSortlblRivRagioneSociale = (Image)GVSchede.HeaderRow.FindControl("imgSortlblRivRagioneSociale");
            imgSortlblRivRagioneSociale.ImageUrl = "";
            Image imgSortlblCliRagioneSociale = (Image)GVSchede.HeaderRow.FindControl("imgSortlblCliRagioneSociale");
            imgSortlblCliRagioneSociale.ImageUrl = "";

            switch ((string)ViewState["strSortExpression"])
            {
                case "id":
                    imgSortlnkid.ImageUrl = (string)ViewState["imgSortDir"];
                    break;
                case "ma":
                    imgSortlnkMA.ImageUrl = (string)ViewState["imgSortDir"];
                    break;
                case "stato":
                    imgSortlnkStato.ImageUrl = (string)ViewState["imgSortDir"];
                    break;
                case "Agente_1":
                    imgSortlblU1Nominativo.ImageUrl = (string)ViewState["imgSortDir"];
                    break;
                case "Agente_2":
                    imgSortlblU2Nominativo.ImageUrl = (string)ViewState["imgSortDir"];
                    break;
                case "Responsabile":
                    imgSortlblURNominativo.ImageUrl = (string)ViewState["imgSortDir"];
                    break;
                case "Rivenditore":
                    imgSortlblRivRagioneSociale.ImageUrl = (string)ViewState["imgSortDir"];
                    break;
                case "Cliente":
                    imgSortlblCliRagioneSociale.ImageUrl = (string)ViewState["imgSortDir"];
                    break;
            }

            if ((string)ViewState["idScheda"] != "")
            {
                var idScheda = (TextBox)GVSchede.HeaderRow.FindControl("txtid");
                if (idScheda != null)
                    idScheda.Text = ViewState["idScheda"].ToString();
            }

            if ((string)ViewState["MA"] != "")
            {
                DropDownList ddlMA = (DropDownList)GVSchede.HeaderRow.FindControl("ddlMA");
                if (ddlMA != null)
                    ddlMA.SelectedValue = ViewState["MA"].ToString().ToUpper();
            }

            if ((string)ViewState["stato"] != "")
            {
                DropDownList ddlStato = (DropDownList)GVSchede.HeaderRow.FindControl("ddlStato");
                if (ddlStato != null)
                    ddlStato.SelectedValue = ViewState["stato"].ToString().ToUpper();
            }

            if ((string)ViewState["U1Nominativo"] != "")
            {
                var U1Nominativo = (TextBox)GVSchede.HeaderRow.FindControl("txtU1Nominativo");
                if (U1Nominativo != null)
                    U1Nominativo.Text = ViewState["U1Nominativo"].ToString().ToUpper();
            }
            if ((string)ViewState["U2Nominativo"] != "")
            {
                var U2Nominativo = (TextBox)GVSchede.HeaderRow.FindControl("txtU2Nominativo");
                if (U2Nominativo != null)
                    U2Nominativo.Text = ViewState["U2Nominativo"].ToString().ToUpper();
            }
            if ((string)ViewState["URNominativo"] != "")
            {
                var URNominativo = (TextBox)GVSchede.HeaderRow.FindControl("txtURNominativo");
                if (URNominativo != null)
                    URNominativo.Text = ViewState["URNominativo"].ToString().ToUpper();
            }
            if ((string)ViewState["RivRagioneSociale"] != "")
            {
                var RivNominativo = (TextBox)GVSchede.HeaderRow.FindControl("txtRivRagioneSociale");
                if (RivNominativo != null)
                    RivNominativo.Text = ViewState["RivRagioneSociale"].ToString().ToUpper();
            }
            if ((string)ViewState["CliRagioneSociale"] != "")
            {
                var CliNominativo = (TextBox)GVSchede.HeaderRow.FindControl("txtCliRagioneSociale");
                if (CliNominativo != null)
                    CliNominativo.Text = ViewState["CliRagioneSociale"].ToString().ToUpper();
            }
            if ((string)ViewState["Validita_Da"] != "")
            {
                DropDownList ddlValidita_Da = (DropDownList)GVSchede.HeaderRow.FindControl("ddlValidita_Da");
                if (ddlValidita_Da != null)
                    ddlValidita_Da.SelectedValue = (string)ViewState["Validita_Da"];
            }
            if ((string)ViewState["Validita_A"] != "")
            {
                DropDownList ddlValidita_A = (DropDownList)GVSchede.HeaderRow.FindControl("ddlValidita_A");
                if (ddlValidita_A != null)
                    ddlValidita_A.SelectedValue = (string)ViewState["Validita_A"];
            }
        }
        protected void chkHeader_CheckedChanged(object sender, EventArgs e)
        {
            var ChkBoxHeader = GVSchede.HeaderRow.FindControl("chkHeader") as CheckBox;
            foreach (GridViewRow row in GVSchede.Rows)
            {
                var ChkBoxItem = row.FindControl("chkItem") as CheckBox;
                if (ChkBoxHeader.Checked == true)
                {
                    ChkBoxItem.Checked = true;
                }
                else
                {
                    ChkBoxItem.Checked = false;
                }
            }
        }
        protected void chkItem_CheckedChanged(object sender, EventArgs e)
        {
            var ChkBoxHeader = GVSchede.HeaderRow.FindControl("chkHeader") as CheckBox;
            if (ChkBoxHeader.Checked == true)
                ChkBoxHeader.Checked = false;
        }

        protected void GVSchede_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVSchede.PageIndex = e.NewPageIndex;
            BindGrid((string)ViewState["strSortExpression"], (string)ViewState["strSortDirection"]);
        }

        protected void GVSchede_Sorting(object sender, GridViewSortEventArgs e)
        {
            e.Cancel = true;

            ViewState["strSortExpression"] = e.SortExpression;
            //Session["strSortExpression"] = e.SortExpression;


            if ((string)ViewState["strSortDirection"] == "Asc")
            {
                ViewState["strSortDirection"] = "Desc";
                ViewState["imgSortDir"] = @"Images\SortDown.jpg";
            }
            else
            {
                ViewState["strSortDirection"] = "Asc";
                ViewState["imgSortDir"] = @"Images\SortUp.jpg";
            }

            ViewState["strSortExpression"] = e.SortExpression;
            Session["strSortExpression"] = e.SortExpression;
            ViewState["idScheda"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtid")).Text.ToString();
            Session["idScheda"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtid")).Text.ToString();
            ViewState["MA"] = ((DropDownList)GVSchede.HeaderRow.FindControl("ddlMA")).SelectedValue.ToString();
            Session["MA"] = ((DropDownList)GVSchede.HeaderRow.FindControl("ddlMA")).SelectedValue.ToString();
            ViewState["stato"] = ((DropDownList)GVSchede.HeaderRow.FindControl("ddlStato")).SelectedValue.ToString();
            Session["stato"] = ((DropDownList)GVSchede.HeaderRow.FindControl("ddlStato")).SelectedValue.ToString();
            ViewState["U1Nominativo"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtU1Nominativo")).Text.ToString();
            Session["U1Nominativo"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtU1Nominativo")).Text.ToString();
            ViewState["U2Nominativo"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtU2Nominativo")).Text.ToString();
            Session["U2Nominativo"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtU2Nominativo")).Text.ToString();
            ViewState["URNominativo"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtURNominativo")).Text.ToString();
            Session["URNominativo"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtURNominativo")).Text.ToString();
            ViewState["RivRagioneSociale"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtRivRagioneSociale")).Text.ToString();
            Session["RivRagioneSociale"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtRivRagioneSociale")).Text.ToString();
            ViewState["CliRagioneSociale"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtCliRagioneSociale")).Text.ToString();
            Session["CliRagioneSociale"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtCliRagioneSociale")).Text.ToString();
            ViewState["Validita_Da"] = ((DropDownList)GVSchede.HeaderRow.FindControl("ddlValidita_Da")).SelectedValue.ToString();
            Session["Validita_Da"] = ((DropDownList)GVSchede.HeaderRow.FindControl("ddlValidita_Da")).SelectedValue.ToString();
            ViewState["Validita_A"] = ((DropDownList)GVSchede.HeaderRow.FindControl("ddlValidita_A")).SelectedValue.ToString();
            Session["Validita_A"] = ((DropDownList)GVSchede.HeaderRow.FindControl("ddlValidita_A")).SelectedValue.ToString();

            BindGrid((string)ViewState["strSortExpression"], (string)ViewState["strSortDirection"]);
        }
        protected void GVSchede_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                if (e.Row.RowType == DataControlRowType.Header)
                    RipristinaFiltri();
            }
        }

        private void MessageBox(string message, string title = "title")
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), title, "alert('" + message + "');", true);
        }
        protected void btnDefault_Click(object sender, EventArgs e)
        {
            ViewState["idScheda"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtid")).Text.ToString();
            Session["idScheda"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtid")).Text.ToString();
            ViewState["MA"] = ((DropDownList)GVSchede.HeaderRow.FindControl("ddlMA")).SelectedValue.ToString();
            Session["MA"] = ((DropDownList)GVSchede.HeaderRow.FindControl("ddlMA")).SelectedValue.ToString();
            ViewState["stato"] = ((DropDownList)GVSchede.HeaderRow.FindControl("ddlStato")).SelectedValue.ToString();
            Session["stato"] = ((DropDownList)GVSchede.HeaderRow.FindControl("ddlStato")).SelectedValue.ToString();
            ViewState["U1Nominativo"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtU1Nominativo")).Text.ToString();
            Session["U1Nominativo"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtU1Nominativo")).Text.ToString();
            ViewState["U2Nominativo"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtU2Nominativo")).Text.ToString();
            Session["U2Nominativo"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtU2Nominativo")).Text.ToString();
            ViewState["URNominativo"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtURNominativo")).Text.ToString();
            Session["URNominativo"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtURNominativo")).Text.ToString();
            ViewState["RivRagioneSociale"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtRivRagioneSociale")).Text.ToString();
            Session["RivRagioneSociale"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtRivRagioneSociale")).Text.ToString();
            ViewState["CliRagioneSociale"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtCliRagioneSociale")).Text.ToString();
            Session["CliRagioneSociale"] = ((TextBox)GVSchede.HeaderRow.FindControl("txtCliRagioneSociale")).Text.ToString();
            ViewState["Validita_Da"] = ((DropDownList)GVSchede.HeaderRow.FindControl("ddlValidita_Da")).SelectedValue.ToString();
            Session["Validita_Da"] = ((DropDownList)GVSchede.HeaderRow.FindControl("ddlValidita_Da")).SelectedValue.ToString();
            ViewState["Validita_A"] = ((DropDownList)GVSchede.HeaderRow.FindControl("ddlValidita_A")).SelectedValue.ToString();
            Session["Validita_A"] = ((DropDownList)GVSchede.HeaderRow.FindControl("ddlValidita_A")).SelectedValue.ToString();

            BindGrid((string)ViewState["strSortExpression"], (string)ViewState["strSortDirection"]);
        }
        protected void btnSchedeDaRpristinare_Click(object sender, EventArgs e)
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                try
                {
                    long lidIntestazione = 0;
                    foreach (GridViewRow GVSchedeRow in GVSchede.Rows)
                    {
                        CheckBox chkItem = (CheckBox)GVSchedeRow.FindControl("chkItem");
                        if (chkItem.Checked == true)
                        {
                            Label lblid = (Label)GVSchedeRow.FindControl("lblid");
                            lidIntestazione = Convert.ToInt32(lblid.Text);
                            lidSchedaErrore = lidIntestazione;

                            var intestazione = context.Schede_Intestazione.FirstOrDefault(S => S.id == lidIntestazione);

                            intestazione.flag_DaNonRinnovare = false;

                            context.SaveChanges();
                            ut.InsLog(SIEMENS_GID, "Ripristino", lidIntestazione, "INFO", "Flag: DA RINNOVARE");

                        }
                    }
                    //Response.Redirect("MainSchedeRinnova.aspx", false);
                    BindGrid((string)ViewState["strSortExpression"], (string)ViewState["strSortDirection"]);
                }
                catch (System.Exception ex)
                {
                    ut.InsLog(SIEMENS_GID, "Ripristino", lidSchedaErrore, "ERRORE", ex.ToString());
                    MessageBox("Si è verificato un errore durante la modifica del flag da rinnovare della scheda " + lidSchedaErrore.ToString() +
                               ". La procedura di aggiornamento è stata bloccata, consultare il log.", "Errore aggiornamento Schede");
                    BindGrid((string)ViewState["strSortExpression"], (string)ViewState["strSortDirection"]);
                }
            }
        }
    }
}