﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace OCCDist
{
    public partial class ModRivendtori : System.Web.UI.Page
    {
        private static string SIEMENS_GID = "";
        private Utilities ut = new Utilities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SIEMENS_GID = (string)Session["SIEMENS_GID"];
                KN.Text = Request.QueryString["KN"];
                using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
                {
                    var rivenditore = context.Rivenditori.FirstOrDefault(R => R.KN == KN.Text);
                    RagioneSociale.Text = rivenditore.Ragione_Sociale;
                    PartitaIva.Text = rivenditore.PartitaIva;
                    Ricarica.Checked = Convert.ToBoolean(rivenditore.flg_Ricarica);
                    Principale.Checked = Convert.ToBoolean(rivenditore.flg_Principale);
                    if (Principale.Checked == true)
                    {
                        btnFamSC.Visible = true;
                        CaricaFamScRivenditore();

                        btnRicMf.Visible = true;
                        CaricaRicMf();

                        btnRicMfVal.Visible = true;
                        CaricaRicMfVal();
                    }
                    Codice_MacroArea.DataSource = context.GetMacroaree(SIEMENS_GID).ToList();
                    Codice_MacroArea.DataBind();
                    Codice_MacroArea.SelectedValue = rivenditore.Codice_MacroArea;
                    GVAssociaMacroArea.DataSource = (from C in context.MacroArea select new { C.Codice }).ToList();
                    GVAssociaMacroArea.DataBind();
                }
            }
        }
        protected void GVAssociaMacroArea_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            string strMacroArea = "";
            if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                strMacroArea = e.Row.Cells[0].Text;

                using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
                {
                    CheckBox chkMacroArea = (CheckBox)e.Row.FindControl("chkMacroArea");
                    var rivenditoreMacroarea = context.RivenditoriMacroarea.FirstOrDefault(RM => RM.Codice_MacroArea == strMacroArea && RM.KN == KN.Text);
                    if (rivenditoreMacroarea != null)
                        chkMacroArea.Checked = true;
                }
            }
        }
        protected void chkMacroArea_CheckedChanged(object sender, EventArgs e)
        {
            GridViewRow row = ((GridViewRow)((CheckBox)sender).NamingContainer);
            CheckBox chkMacroArea = (CheckBox)GVAssociaMacroArea.Rows[row.RowIndex].FindControl("chkMacroArea");
            if (chkMacroArea.Checked == false) // Precedentemente era true, quindi si vorrebbe cancellare una associazione con una macroarea, bisogna controllare se è associato ad una scheda
            {
                string strMacroArea = GVAssociaMacroArea.Rows[row.RowIndex].Cells[0].Text;
                using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
                {
                    var qrySchede = context.Schede_Intestazione.FirstOrDefault(S => S.Codice_MacroArea == strMacroArea
                        && S.Rivenditore_KN == KN.Text);
                    if (qrySchede != null) // esiste almeno una scheda per cui KN è rivenditore, non si può cancellare, riposizionamo a true il checkbox
                    {
                        chkMacroArea.Checked = true;
                        string strControllo = "<font color=red><ul>";
                        strControllo = strControllo + "<li> Cancellazione bloccata! Esiste almeno una scheda per cui " + KN.Text + " è rivenditore </li>";
                        strControllo = strControllo + "</ul></font>";
                        ErrorMessage.Text = strControllo;
                    }
                }
            }
        }
        private bool Controllo()
        {
            string strControllo = "";
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                strControllo = "<font color=red><ul>";
                foreach (GridViewRow GVAssociaMacroAreaRow in GVAssociaMacroArea.Rows)
                {
                    string strMacroArea = GVAssociaMacroAreaRow.Cells[0].Text;

                    var qrySchede = context.Schede_Intestazione.FirstOrDefault(S => S.Codice_MacroArea == strMacroArea
                        && S.Rivenditore_KN == KN.Text);
                    if (qrySchede != null) // esiste almeno una scheda per cui KN è rivenditore, non si può cancellare, riposizionamo a true il checkbox
                    {
                        strControllo = strControllo + "<li> Cancellazione bloccata! Esiste almeno una scheda per cui " + KN.Text + " è rivenditore </li>";
                        break; // esce dal foreach
                    }
                }
                strControllo = strControllo + "</ul></font>";
            }
            if (strControllo == "<font color=red><ul></ul></font>") // nessun impedimento
                return true;
            else
            {
                ErrorMessage.Text = strControllo;
                return false;
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            if (Controllo())
            {
                using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
                {
                    foreach (GridViewRow GVAssociaMacroAreaRow in GVAssociaMacroArea.Rows)
                    {
                        string strMacroArea = GVAssociaMacroAreaRow.Cells[0].Text;

                        var qryRivenditoreMacroarea = context.RivenditoriMacroarea.FirstOrDefault(RM => RM.Codice_MacroArea == strMacroArea && RM.KN == KN.Text);
                        if (qryRivenditoreMacroarea != null) // Lo deve cancellare
                        {
                            context.RivenditoriMacroarea.Remove(qryRivenditoreMacroarea);
                            context.SaveChanges();
                            ut.InsLog(SIEMENS_GID, "Rivenditori", 0, "INFO", "Eliminata associazione: " + strMacroArea + "|" + KN.Text);
                        }
                    }

                    var rivenditore = context.Rivenditori.First(R => R.KN == KN.Text);
                    context.Rivenditori.Remove(rivenditore);
                    context.SaveChanges();

                    ut.InsLog(SIEMENS_GID, "Rivenditori", 0, "INFO", "Eliminato rivenditore: " + KN.Text + "|" + RagioneSociale.Text);

                    Response.Redirect("MainRivenditori.aspx", false);
                }
            }
        }

        protected void btnUpdate_Click(object sender, EventArgs e)
        {
            if (ControlloPrincipale())
            {
                using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
                {
                    var rivenditore = context.Rivenditori.First(R => R.KN == KN.Text);
                    rivenditore.KN = KN.Text;
                    rivenditore.Ragione_Sociale = RagioneSociale.Text;
                    rivenditore.PartitaIva = PartitaIva.Text;
                    rivenditore.flg_Ricarica = Convert.ToBoolean(Ricarica.Checked);
                    rivenditore.flg_Principale = Convert.ToBoolean(Principale.Checked);
                    rivenditore.Codice_MacroArea = Codice_MacroArea.SelectedValue;
                    context.SaveChanges();

                    ut.InsLog(SIEMENS_GID, "Rivenditori", 0, "INFO", "Modificato rivenditore: " + rivenditore.Ragione_Sociale);

                    foreach (GridViewRow GVAssociaMacroAreaRow in GVAssociaMacroArea.Rows)
                    {
                        string strMacroArea = GVAssociaMacroAreaRow.Cells[0].Text;

                        CheckBox chkMacroArea = (CheckBox)GVAssociaMacroAreaRow.FindControl("chkMacroArea");
                        var qryRivenditoreMacroarea = context.RivenditoriMacroarea.FirstOrDefault(RM => RM.Codice_MacroArea == strMacroArea && RM.KN == KN.Text);
                        //if (chkMacroArea.Checked == true && qryRivenditoreMacroarea != null) // Non deve fare nulla
                        //{}
                        //if (chkMacroArea.Checked == false && qryRivenditoreMacroarea == null) // Non deve fare nulla
                        //{}
                        if (chkMacroArea.Checked == true && qryRivenditoreMacroarea == null) // Lo deve inserire
                        {
                            RivenditoriMacroarea rivenditoreMacroarea = new RivenditoriMacroarea();
                            rivenditoreMacroarea.KN = KN.Text;
                            rivenditoreMacroarea.Codice_MacroArea = strMacroArea;
                            context.RivenditoriMacroarea.Add(rivenditoreMacroarea);
                            context.SaveChanges();
                            ut.InsLog(SIEMENS_GID, "Rivenditori", 0, "INFO", "Inserita rivenditore per macro area: " + strMacroArea + "|" + rivenditore.Ragione_Sociale);
                        }
                        if (chkMacroArea.Checked == false && qryRivenditoreMacroarea != null) // Lo deve cancellare
                        {
                            context.RivenditoriMacroarea.Remove(qryRivenditoreMacroarea);
                            context.SaveChanges();
                            ut.InsLog(SIEMENS_GID, "Rivenditori", 0, "INFO", "Eliminata associazione: " + strMacroArea + "|" + rivenditore.KN);
                        }
                    }

                    // Cancella tutti i dati associati, tabelle: tb_Fam_SC_Rivenditore, Ricariche_MacroFamiglie, Ricariche_MacroFamiglie_Valori
                    // poi nel caso li reinserisce
                    var qryDelFamScRivenditori = context.DelFamScRivenditore(SIEMENS_GID, KN.Text, PartitaIva.Text);

                    // Inserisce 

                    // Famiglia sconto rivenditore
                    if (Principale.Checked == true)
                    {
                        GVFamScRivenditore.AllowPaging = false;
                        BindFamScRivenditore();
                        foreach (GridViewRow GVFamScRivenditoreRow in GVFamScRivenditore.Rows)
                        {
                            tb_Fam_SC_Rivenditore fam_sc_rivenditore = new tb_Fam_SC_Rivenditore();

                            fam_sc_rivenditore.KN = KN.Text;
                            fam_sc_rivenditore.Codice_Famiglia_Sconti_Siemens = GVFamScRivenditoreRow.Cells[0].Text;
                            fam_sc_rivenditore.Fam_SC = GVFamScRivenditoreRow.Cells[1].Text;

                            context.tb_Fam_SC_Rivenditore.Add(fam_sc_rivenditore);
                        }

                        GVRicMf.AllowPaging = false;
                        BindRicMf();
                        foreach (GridViewRow GVRicMfRow in GVRicMf.Rows)
                        {
                            Ricariche_MacroFamiglie ricariche_macrofamiglie = new Ricariche_MacroFamiglie();

                            ricariche_macrofamiglie.PartitaIva = PartitaIva.Text;
                            ricariche_macrofamiglie.FamigliaSconto = GVRicMfRow.Cells[0].Text;
                            ricariche_macrofamiglie.MacroFamiglia = GVRicMfRow.Cells[1].Text;

                            context.Ricariche_MacroFamiglie.Add(ricariche_macrofamiglie);
                        }

                        GVRicMfVal.AllowPaging = false;
                        BindRicMfVal();
                        foreach (GridViewRow GVRicMfValRow in GVRicMfVal.Rows)
                        {
                            Ricariche_MacroFamiglie_Valori ricariche_macrofamiglie_valori = new Ricariche_MacroFamiglie_Valori();

                            ricariche_macrofamiglie_valori.PartitaIva = PartitaIva.Text;
                            ricariche_macrofamiglie_valori.MacroFamiglia = GVRicMfValRow.Cells[0].Text;
                            ricariche_macrofamiglie_valori.ScontoVenditaMin = Convert.ToDecimal(GVRicMfValRow.Cells[1].Text);
                            ricariche_macrofamiglie_valori.ScontoVenditaMax = Convert.ToDecimal(GVRicMfValRow.Cells[2].Text);
                            ricariche_macrofamiglie_valori.Ricarica = Convert.ToDecimal(GVRicMfValRow.Cells[3].Text);

                            context.Ricariche_MacroFamiglie_Valori.Add(ricariche_macrofamiglie_valori);
                        }
                    }

                    context.SaveChanges();

                    Response.Redirect("MainRivenditori.aspx", false);
                }
            }
        }

        private bool ControlloPrincipale()
        {
            if (Principale.Checked == true)
            {
                string strControllo = "";
                using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
                {
                    strControllo = "<font color=red><ul>";

                    // Controllo stessa partita iva se esiste principale
                    var chkPrincipale = context.Rivenditori.FirstOrDefault(R => R.PartitaIva == PartitaIva.Text && R.flg_Principale == true && R.KN != KN.Text);
                    if (chkPrincipale != null)
                        strControllo = strControllo + "<li> Flag Principale già assegnato al KN: " + chkPrincipale.KN + " " + chkPrincipale.Ragione_Sociale + " con uguale partita Iva: " + chkPrincipale.PartitaIva + "</li>";


                    strControllo = strControllo + "</ul></font>";
                }
                if (strControllo == "<font color=red><ul></ul></font>") // nessun impedimento
                    return true;
                else
                {
                    ErrorMessage.Text = strControllo;
                    return false;
                }
            }
            else
                return true;
        }


        protected void Principale_CheckedChanged(object sender, EventArgs e)
        {
            if (Principale.Checked == true)
            {
                if (ControlloPrincipale()) // Non c'è un principale
                {
                    btnFamSC.Visible = true;
                    btnRicMf.Visible = true;
                    btnRicMfVal.Visible = true;
                }
                else
                {
                    Principale.Checked = false;
                }
            }
            else
            {
                btnFamSC.Visible = false;
                btnRicMf.Visible = false;
                btnRicMfVal.Visible = false;
            }
        }

        protected void btnFamScRivenditore_Click(object sender, EventArgs e)
        {
        }
        private void MessageBox(string message, string title = "title")
        {
            ScriptManager.RegisterStartupScript(this.Page, this.Page.GetType(), title, "alert('" + message + "');", true);
        }

        protected void CaricaFamScRivenditore()
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                var fam_sc_rivenditore = context.tb_Fam_SC_Rivenditore
                    .Where(SCR => SCR.KN == KN.Text);
                    //.OrderBy(I => I.Codice_Materiale).ToList();

                string strFamScRivenditore = "";
                foreach (tb_Fam_SC_Rivenditore item in fam_sc_rivenditore)
                {
                    strFamScRivenditore = strFamScRivenditore + item.Codice_Famiglia_Sconti_Siemens + '\t';
                    strFamScRivenditore = strFamScRivenditore + item.Fam_SC + '\n';
                }
                ViewState["FamScRivenditore"] = strFamScRivenditore;
                BindFamScRivenditore();

                //idBadgeFamScRivenditore.InnerText = (fam_sc_rivenditore.Count).ToString();
            }
        }
        protected void btnFamSC_Click(object sender, EventArgs e)
        {
            ModalPopupFamScRivenditore.Show();
        }
        protected void BindFamScRivenditore()
        {
            DataTable dt = new DataTable();
            dt.Columns.AddRange(new DataColumn[2] { new DataColumn("Codice_Famiglia_Sconti_Siemens", typeof(string)),
                    new DataColumn("Fam_SC", typeof(string)) });

            string strFamScRivenditore = (string)ViewState["FamScRivenditore"];
            foreach (string row in strFamScRivenditore.Split('\n'))
            {
                if (!string.IsNullOrEmpty(row))
                {
                    dt.Rows.Add();
                    int i = 0;
                    foreach (string cell in row.Split('\t'))
                    {
                        dt.Rows[dt.Rows.Count - 1][i] = cell;
                        i++;
                    }
                }
            }
            GVFamScRivenditore.DataSource = dt;
            GVFamScRivenditore.DataBind();

            //idBadgePrezziNetti.InnerText = (dt.Rows.Count).ToString();

        }
        protected void GVFamScRivenditore_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVFamScRivenditore.PageIndex = e.NewPageIndex;
            BindFamScRivenditore();
            ModalPopupFamScRivenditore.Show();
        }

        protected void btnDelGrid_Click(object sender, EventArgs e)
        {
            ViewState["FamScRivenditore"] = "";
            BindFamScRivenditore();
            ModalPopupFamScRivenditore.Show();
        }
        protected void btnExportFromGrid_Click(object sender, EventArgs e)
        {
            txtCopied.Text = (string)ViewState["FamScRivenditore"];
            ModalPopupFamScRivenditore.Show();
        }
        protected void btnImportInGrid_Click(object sender, EventArgs e)
        {
            ViewState["FamScRivenditore"] = txtCopied.Text;
            BindFamScRivenditore();
            txtCopied.Text = "";
            ModalPopupFamScRivenditore.Show();
        }

        // RICARICHE MACROFAMIGLIE
        protected void CaricaRicMf()
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                var ricariche_macrofamiglie = context.Ricariche_MacroFamiglie
                    .Where(RMF => RMF.PartitaIva == PartitaIva.Text)
                    .OrderBy(RMF => RMF.MacroFamiglia).ToList();

                string strRicMf = "";
                foreach (Ricariche_MacroFamiglie item in ricariche_macrofamiglie)
                {
                    strRicMf = strRicMf + item.FamigliaSconto + '\t';
                    strRicMf = strRicMf + item.MacroFamiglia + '\n';
                }
                ViewState["RicMf"] = strRicMf;
                BindRicMf();

            }
        }
        protected void btnRicMf_Click(object sender, EventArgs e)
        {
            ModalPopupRicMf.Show();
        }
        protected void BindRicMf()
        {
            DataTable dt = new DataTable();
            dt.Columns.AddRange(new DataColumn[2] { new DataColumn("FamigliaSconto", typeof(string)),
                    new DataColumn("MacroFamiglia", typeof(string)) });

            string strRicMf = (string)ViewState["RicMf"];
            foreach (string row in strRicMf.Split('\n'))
            {
                if (!string.IsNullOrEmpty(row))
                {
                    dt.Rows.Add();
                    int i = 0;
                    foreach (string cell in row.Split('\t'))
                    {
                        dt.Rows[dt.Rows.Count - 1][i] = cell;
                        i++;
                    }
                }
            }
            GVRicMf.DataSource = dt;
            GVRicMf.DataBind();

        }
        protected void GVRicMf_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVRicMf.PageIndex = e.NewPageIndex;
            BindRicMf();
            ModalPopupRicMf.Show();
        }

        protected void btnDelGridRicMf_Click(object sender, EventArgs e)
        {
            ViewState["RicMf"] = "";
            BindRicMf();
            ModalPopupRicMf.Show();
        }
        protected void btnExportFromGridRicMf_Click(object sender, EventArgs e)
        {
            txtCopiedRicMf.Text = (string)ViewState["RicMf"];
            ModalPopupRicMf.Show();
        }
        protected void btnImportInGridRicMf_Click(object sender, EventArgs e)
        {
            ViewState["RicMf"] = txtCopiedRicMf.Text;
            BindRicMf();
            txtCopiedRicMf.Text = "";
            ModalPopupRicMf.Show();
        }

        // RICARICHE MACROFAMIGLIE VALORI
        protected void CaricaRicMfVal()
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                var ricariche_macrofamiglie_valori = context.Ricariche_MacroFamiglie_Valori
                    .Where(RMFV => RMFV.PartitaIva == PartitaIva.Text)
                    .OrderBy(RMFV => RMFV.MacroFamiglia).ToList();

                string strRicMfVal = "";
                foreach (Ricariche_MacroFamiglie_Valori item in ricariche_macrofamiglie_valori)
                {
                    strRicMfVal = strRicMfVal + item.MacroFamiglia + '\t';
                    strRicMfVal = strRicMfVal + item.ScontoVenditaMin + '\t';
                    strRicMfVal = strRicMfVal + item.ScontoVenditaMax + '\t';
                    strRicMfVal = strRicMfVal + item.Ricarica + '\n';
                }
                ViewState["RicMfVal"] = strRicMfVal;
                BindRicMfVal();

            }
        }
        protected void btnRicMfVal_Click(object sender, EventArgs e)
        {
            ModalPopupRicMfVal.Show();
        }
        protected void BindRicMfVal()
        {
            DataTable dt = new DataTable();
            dt.Columns.AddRange(new DataColumn[4] { new DataColumn("MacroFamiglia", typeof(string)),
                    new DataColumn("ScontoVenditaMin", typeof(float)),
                    new DataColumn("ScontoVenditaMax", typeof(float)),
                    new DataColumn("Ricarica", typeof(float)) });

            string strRicMfVal = (string)ViewState["RicMfVal"];
            foreach (string row in strRicMfVal.Split('\n'))
            {
                if (!string.IsNullOrEmpty(row))
                {
                    dt.Rows.Add();
                    int i = 0;
                    foreach (string cell in row.Split('\t'))
                    {
                        dt.Rows[dt.Rows.Count - 1][i] = cell;
                        i++;
                    }
                }
            }
            GVRicMfVal.DataSource = dt;
            GVRicMfVal.DataBind();

        }
        protected void GVRicMfVal_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVRicMfVal.PageIndex = e.NewPageIndex;
            BindRicMfVal();
            ModalPopupRicMfVal.Show();
        }

        protected void btnDelGridRicMfVal_Click(object sender, EventArgs e)
        {
            ViewState["RicMfVal"] = "";
            BindRicMfVal();
            ModalPopupRicMfVal.Show();
        }
        protected void btnExportFromGridRicMfVal_Click(object sender, EventArgs e)
        {
            txtCopiedRicMfVal.Text = (string)ViewState["RicMfVal"];
            ModalPopupRicMfVal.Show();
        }
        protected void btnImportInGridRicMfVal_Click(object sender, EventArgs e)
        {
            ViewState["RicMfVal"] = txtCopiedRicMfVal.Text;
            BindRicMfVal();
            txtCopiedRicMfVal.Text = "";
            ModalPopupRicMfVal.Show();
        }
    }
}