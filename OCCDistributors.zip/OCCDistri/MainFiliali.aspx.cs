﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OCCDist
{
    public partial class MainFiliali : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ViewState["NomeFiliale"] = "";
                BindGrid();
            }
        }
        void BindGrid()
        {
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                string SIEMENS_GID = (string)Session["SIEMENS_GID"];

                var qryCanCreateNew = context.CanCreateNew(SIEMENS_GID).ToList();
                if (qryCanCreateNew.Count > 0)
                {
                    idHypCreaNuova.Visible = true; // Abilita il link per creare una nuova filiale
                }

                if ((string)ViewState["NomeFiliale"] == "")
                {
                    var query = from F in context.Filiali
                                orderby F.Codice
                                select F;
                    GVFiliali.DataSource = query.ToList();
                }
                else
                {
                    string strFilter = (string)ViewState["NomeFiliale"];
                    var query = from F in context.Filiali
                                where F.Codice.StartsWith(strFilter)
                                orderby F.Codice
                                select F;

                    GVFiliali.DataSource = query.ToList();
                }

                GVFiliali.DataBind();
            }
        }
        protected void GVFiliali_SelectedIndexChanged(object sender, EventArgs e)
        {
            string strTmp = ((LinkButton)GVFiliali.SelectedRow.FindControl("lblNomeFiliale")).Text.ToString();
            strTmp = strTmp + @"&azione=Modifica";
            Response.Redirect("ModFiliali.aspx?NomeFiliale=" + strTmp, false);
        }
        protected void GVFiliali_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVFiliali.PageIndex = e.NewPageIndex;
            BindGrid();
        }
        protected void GVFiliali_Sorting(object sender, GridViewSortEventArgs e)
        {
            e.Cancel = true;

            ViewState["NomeFiliale"] = ((TextBox)GVFiliali.HeaderRow.FindControl("txtNomeFiliale")).Text.ToString();
            BindGrid();
        }
        protected void btnDefault_Click(object sender, EventArgs e)
        {
            ViewState["NomeFiliale"] = ((TextBox)GVFiliali.HeaderRow.FindControl("txtNomeFiliale")).Text.ToString();
            BindGrid();
        }
        protected void GVFiliali_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                if ((string)ViewState["NomeFiliale"] != "")
                {
                    var NomeFiliale = (TextBox)GVFiliali.HeaderRow.FindControl("txtNomeFiliale");
                    if (NomeFiliale != null)
                        NomeFiliale.Text = ViewState["NomeFiliale"].ToString().ToUpper();
                }
            }
        }
    }
}