﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OCCDist
{
    public partial class InsClienti : System.Web.UI.Page
    {
        private static string SIEMENS_GID = "";
        private Utilities ut = new Utilities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SIEMENS_GID = (string)Session["SIEMENS_GID"];
                using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
                {
                    Codice_MacroArea.DataSource = context.GetMacroaree(SIEMENS_GID).ToList();
                    Codice_MacroArea.DataBind();

                    var qryAttivita = from CA in context.ClientiAttivita select CA;
                    ddlAttivita.DataValueField = "Attivita";
                    ddlAttivita.DataTextField = "Attivita";
                    ddlAttivita.DataSource = qryAttivita.ToList();
                    ddlAttivita.DataBind();
                    // inserisce un item blank 
                    ddlAttivita.Items.Insert(0, new ListItem(String.Empty, String.Empty));
                }
            }
        }

        protected void btnInsert_Click(object sender, EventArgs e)
        {
            if (Controllo())
            {
                using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
                {
                    Clienti cliente = new Clienti();
                    cliente.Ragione_Sociale = RagioneSociale.Text;
                    cliente.P_Iva = PartitaIva.Text;
                    cliente.Comune = Comune.Text;
                    cliente.CAP = CAP.Text;
                    cliente.Provincia = Provincia.Text;
                    cliente.Codice_MacroArea = Codice_MacroArea.SelectedValue;

                    if (Elettromeccanica_Pot.Text != "")
                        cliente.Elettromeccanica_Pot = Convert.ToInt32(Elettromeccanica_Pot.Text);
                    else
                        cliente.Elettromeccanica_Pot = 0;

                    if (Infrastruttura_Pot.Text != "")
                        cliente.Infrastruttura_Pot = Convert.ToInt32(Infrastruttura_Pot.Text);
                    else
                        cliente.Infrastruttura_Pot = 0;

                    if (Automazione_Pot.Text != "")
                        cliente.Automazione_Pot = Convert.ToInt32(Automazione_Pot.Text);
                    else
                        cliente.Automazione_Pot = 0;

                    if (Inverter_Pot.Text != "")
                        cliente.Inverter_Pot = Convert.ToInt32(Inverter_Pot.Text);
                    else
                        cliente.Inverter_Pot = 0;

                    if (ddlAttivita.SelectedValue != "")
                        cliente.Attivita = ddlAttivita.SelectedValue;
                    else
                        cliente.Attivita = null;

                    context.Clienti.Add(cliente);
                    context.SaveChanges();

                    ut.InsLog(SIEMENS_GID, "Clienti", 0, "INFO", "Inserito cliente: " + cliente.Ragione_Sociale);

                    //Session["idUltimoClienteInserito"] = cliente.Ragione_Sociale;
                    Response.Redirect("MainClienti.aspx", false);
                }
            }
        }
        private bool Controllo()
        {
            string strControllo = "";
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                strControllo = "<font color=red><ul>";

                var cliente = context.Clienti.FirstOrDefault(C => C.P_Iva == PartitaIva.Text && C.Comune == Comune.Text);

                if (cliente != null)
                    strControllo = strControllo + "<li> Partita IVA e Comune già assegnati al codice: " + cliente.id + "|" + cliente.Ragione_Sociale + "</li>";

                strControllo = strControllo + "</ul></font>";
            }
            if (strControllo == "<font color=red><ul></ul></font>") // nessun impedimento
                return true;
            else
            {
                ErrorMessage.Text = strControllo;
                return false;
            }
        }
    }
}