﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace OCCDist
{
    public partial class TestTable : System.Web.UI.Page
    {
        private string tmpRaggruppamento = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                ViewState["A1Cognome"] = "";
                ViewState["A2Cognome"] = "";
                ViewState["ARCognome"] = "";
                ViewState["Ragione_Sociale"] = "";
                ViewState["Ragione_Sociale_Riv"] = "";
                BindData();
            }
            if (GVDettaglio.Rows.Count > 0)
            {
                if (!chkRicRivenditore.Checked) // Rivenditore con flg ricarica = false
                {
                    GVDettaglio.HeaderRow.Cells[8].Text = ""; // il ciclo foreach che segue non comtempla l'header       
                }
                foreach (GridViewRow GVDettaglioRow in GVDettaglio.Rows)
                {
                    HiddenField hidSC_Finale = (HiddenField)GVDettaglioRow.FindControl("hidSC_Finale");
                    if (!string.IsNullOrEmpty(hidSC_Finale.Value))
                    {
                        Label lblSC_Finale = (Label)GVDettaglioRow.FindControl("lblSC_Finale");
                        lblSC_Finale.Text = hidSC_Finale.Value;
                    }
                    if (!chkRicRivenditore.Checked) // Rivenditore con flg ricarica = false
                    {
                        GVDettaglioRow.Cells[8].Text = ""; //  colonna "Ric."
                    }
                }
            }
        }
        void BindData()
        {
            using (OCCEntities context = new OCCEntities())
            {
                string SIEMENS_GID = (string)Session["SIEMENS_GID"];

                ddlMacroArea.DataValueField = "Codice_MacroArea";
                ddlMacroArea.DataTextField = "Codice_MacroArea";
                ddlMacroArea.DataSource = context.CanCreateNew(SIEMENS_GID).ToList();
                ddlMacroArea.DataBind();

                ddlStatoScheda.DataValueField = "Codice";
                ddlStatoScheda.DataTextField = "Descrizione";
                ddlStatoScheda.DataSource = context.StatiNuovaScheda(SIEMENS_GID).ToList();
                ddlStatoScheda.SelectedValue = "B";
                ddlStatoScheda.DataBind();
            }
        }

        protected void btnSearchModello_Click(object sender, EventArgs e)
        {
            using (OCCEntities context = new OCCEntities())
            {
                if (context.Modelli_Intestazione.Count() > 0)
                {
                    var query = from M in context.Modelli_Intestazione select new { M.id, M.Descrizione, M.Validita_Da, M.Validita_A };
                    GVModelli.DataSource = query.ToList();
                    GVModelli.DataBind();
                }
            }
            ModalPopupModelli.Show();
        }
        protected void GVModelli_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVModelli.PageIndex = e.NewPageIndex;
            GVModelli.DataBind();
        }
        protected void GVModelli_SelectedIndexChanged(object sender, EventArgs e)
        {
            id_modello.Text = GVModelli.SelectedRow.Cells[1].Text;
            lbl_Descr_Modello.Text = GVModelli.SelectedRow.Cells[2].Text;
            GVModelli.DataSource = null;
            GVModelli.DataBind();

        }
        protected void GVDettaglio_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.Header)
                if (!chkRicRivenditore.Checked) // Rivenditore con flg ricarica = false
                {
                    e.Row.Cells[8].Text = ""; // intestazione colonna "Ric."
                }
            if (e.Row.RowType == DataControlRowType.DataRow && (e.Row.RowState == DataControlRowState.Normal || e.Row.RowState == DataControlRowState.Alternate))
            {
                Label lblDescProd = (Label)e.Row.FindControl("lblIDescrizione_Prodotto");
                if (lblDescProd.Text == "Raggruppamento")
                {
                    Label lblIDescrizione_Spiridon = (Label)e.Row.FindControl("lblIDescrizione_Spiridon");
                    lblIDescrizione_Spiridon.BackColor = System.Drawing.Color.LightGray;
                    lblIDescrizione_Spiridon.ForeColor = System.Drawing.Color.Gray;
                    Label lblICatalogo = (Label)e.Row.FindControl("lblICatalogo");
                    lblICatalogo.BackColor = System.Drawing.Color.LightGray;
                    lblICatalogo.ForeColor = System.Drawing.Color.Gray;
                    lblDescProd.BackColor = System.Drawing.Color.LightGray;
                    lblDescProd.ForeColor = System.Drawing.Color.Gray;
                    Label lblFamSC = (Label)e.Row.FindControl("lblIFam_SC");
                    lblFamSC.BackColor = System.Drawing.Color.LightGray;
                    lblFamSC.ForeColor = System.Drawing.Color.Gray;
                    e.Row.Font.Bold = true;
                    e.Row.ForeColor = System.Drawing.Color.LightYellow;
                    e.Row.FindControl("lblIFam_SC_Riv").Visible = false;
                    e.Row.FindControl("txtSconto").Visible = false;
                    e.Row.FindControl("txtExtra").Visible = false;
                    e.Row.FindControl("lblSC_Finale").Visible = false;
                    e.Row.FindControl("txtRicarica").Visible = false;
                }
                else
                {
                    if (!chkRicRivenditore.Checked) // Rivenditore con flg ricarica = false
                    {
                        e.Row.Cells[8].Text = ""; //  colonna "Ric."
                    }
                    TextBox txtSconto = (TextBox)e.Row.FindControl("txtSconto");
                    TextBox txtExtra = (TextBox)e.Row.FindControl("txtExtra");
                    HiddenField hidSC_Finale = (HiddenField)e.Row.FindControl("hidSC_Finale");
                    Label lblSC_Finale = (Label)e.Row.FindControl("lblSC_Finale");
                    txtExtra.Attributes.Add("onblur", "CalcolaSconto('" + txtSconto.ClientID + "','" + txtExtra.ClientID + "','" + hidSC_Finale.ClientID + "','" + lblSC_Finale.ClientID + "')");
                }
            }
        }
        protected void btnSearchAgente_1_Click(object sender, EventArgs e)
        {
            BindAgenti_1("");
            ModalPopupAgenti_1.Show();
        }
        void BindAgenti_1(string SortColumn)
        {
            using (OCCEntities context = new OCCEntities())
            {
                if (SortColumn == "")
                {
                    var query = from A in context.Agenti
                                join U in context.Utenti on A.Gid equals U.GID
                                where A.Codice_MacroArea == ddlMacroArea.SelectedValue
                                orderby U.Cognome
                                select new { A.Codice_MacroArea, A.Gid, U.Cognome, U.Nome };
                    GVAgenti_1.DataSource = query.ToList();
                }
                else
                {
                    string strFilter = (string)ViewState["A1Cognome"];
                    var query = from A in context.Agenti
                                join U in context.Utenti on A.Gid equals U.GID
                                where A.Codice_MacroArea == ddlMacroArea.SelectedValue && U.Cognome.StartsWith(strFilter)
                                orderby U.Cognome
                                select new { A.Codice_MacroArea, A.Gid, U.Cognome, U.Nome };

                    GVAgenti_1.DataSource = query.ToList();
                }
                GVAgenti_1.DataBind();
            }
        }
        protected void GVAgenti_1_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblAgente1.Text = ((Label)GVAgenti_1.SelectedRow.FindControl("lblA1Cognome")).Text.ToString() + " " + GVAgenti_1.SelectedRow.Cells[2].Text;
            lblGid_Agente_1.Text = GVAgenti_1.SelectedRow.Cells[4].Text;
            GVAgenti_1.DataSource = null;
            GVAgenti_1.DataBind();
        }
        protected void GVAgenti_1_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVAgenti_1.PageIndex = e.NewPageIndex;
            BindAgenti_1("");
            ModalPopupAgenti_1.Show();
        }
        protected void GVAgenti_1_Sorting(object sender, GridViewSortEventArgs e)
        {
            ViewState["A1Cognome"] = ((TextBox)GVAgenti_1.HeaderRow.FindControl("txtA1Cognome")).Text.ToString();
            BindAgenti_1(e.SortExpression);
            ModalPopupAgenti_1.Show();
        }

        protected void btnSearchAgente_2_Click(object sender, EventArgs e)
        {
            BindAgenti_2("");
            ModalPopupAgenti_2.Show();
        }
        void BindAgenti_2(string SortColumn)
        {
            using (OCCEntities context = new OCCEntities())
            {
                if (SortColumn == "")
                {
                    var query = from A in context.Agenti
                                join U in context.Utenti on A.Gid equals U.GID
                                where A.Codice_MacroArea == ddlMacroArea.SelectedValue
                                orderby U.Cognome
                                select new { A.Codice_MacroArea, A.Gid, U.Cognome, U.Nome };
                    GVAgenti_2.DataSource = query.ToList();
                }
                else
                {
                    string strFilter = (string)ViewState["A2Cognome"];
                    var query = from A in context.Agenti
                                join U in context.Utenti on A.Gid equals U.GID
                                where A.Codice_MacroArea == ddlMacroArea.SelectedValue && U.Cognome.StartsWith(strFilter)
                                orderby U.Cognome
                                select new { A.Codice_MacroArea, A.Gid, U.Cognome, U.Nome };

                    GVAgenti_2.DataSource = query.ToList();
                }
                GVAgenti_2.DataBind();
            }
        }
        protected void GVAgenti_2_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblAgente2.Text = ((Label)GVAgenti_2.SelectedRow.FindControl("lblA2Cognome")).Text.ToString() + " " + GVAgenti_2.SelectedRow.Cells[2].Text;
            lblGid_Agente_2.Text = GVAgenti_2.SelectedRow.Cells[4].Text;
            GVAgenti_2.DataSource = null;
            GVAgenti_2.DataBind();
        }
        protected void GVAgenti_2_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVAgenti_2.PageIndex = e.NewPageIndex;
            BindAgenti_2("");
            ModalPopupAgenti_2.Show();
        }
        protected void GVAgenti_2_Sorting(object sender, GridViewSortEventArgs e)
        {
            ViewState["A2Cognome"] = ((TextBox)GVAgenti_2.HeaderRow.FindControl("txtA2Cognome")).Text.ToString();
            BindAgenti_2(e.SortExpression);
            ModalPopupAgenti_2.Show();
        }
        protected void btnSearchResponsabili_Click(object sender, EventArgs e)
        {
            BindResponsabili("");
            ModalPopupResponsabili.Show();
        }

        void BindResponsabili(string SortColumn)
        {
            using (OCCEntities context = new OCCEntities())
            {
                if (SortColumn == "")
                {
                    var query = from A in context.Responsabili
                                join U in context.Utenti on A.GID equals U.GID
                                where A.Codice_MacroArea == ddlMacroArea.SelectedValue
                                orderby U.Cognome
                                select new { A.Codice_MacroArea, A.GID, U.Cognome, U.Nome };
                    GVResponsabili.DataSource = query.ToList();
                }
                else
                {
                    string strFilter = (string)ViewState["ARCognome"];
                    var query = from A in context.Responsabili
                                join U in context.Utenti on A.GID equals U.GID
                                where A.Codice_MacroArea == ddlMacroArea.SelectedValue && U.Cognome.StartsWith(strFilter)
                                orderby U.Cognome
                                select new { A.Codice_MacroArea, A.GID, U.Cognome, U.Nome };

                    GVResponsabili.DataSource = query.ToList();
                }
                GVResponsabili.DataBind();
            }
        }
        protected void GVResponsabili_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVResponsabili.PageIndex = e.NewPageIndex;
            BindResponsabili("");
            ModalPopupResponsabili.Show();
        }
        protected void GVResponsabili_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblResponsabile.Text = ((Label)GVResponsabili.SelectedRow.FindControl("lblARCognome")).Text.ToString() + " " + GVResponsabili.SelectedRow.Cells[2].Text;
            lblGid_Responsabile.Text = GVResponsabili.SelectedRow.Cells[4].Text;
            GVResponsabili.DataSource = null;
            GVResponsabili.DataBind();
        }
        protected void GVResponsabili_Sorting(object sender, GridViewSortEventArgs e)
        {
            ViewState["ARCognome"] = ((TextBox)GVResponsabili.HeaderRow.FindControl("txtARCognome")).Text.ToString();
            BindResponsabili(e.SortExpression);
            ModalPopupResponsabili.Show();
        }
        protected void btnSearchClienti_Click(object sender, EventArgs e)
        {
            //btnVisualizzaPrezziNetti.Enabled = false;
            BindClienti("");
            ModalPopupClienti.Show();
        }
        void BindClienti(string SortColumn)
        {
            using (OCCEntities context = new OCCEntities())
            {
                if (context.Clienti.Count() > 0)
                {
                    if (SortColumn == "")
                    {
                        GVClienti.DataSource = context.Clienti
                            .Where(C => C.Codice_MacroArea == ddlMacroArea.SelectedValue)
                            .OrderBy(C => C.Ragione_Sociale).ToList();
                    }
                    else
                    {
                        string strFilter = (string)ViewState["Ragione_Sociale"];
                        GVClienti.DataSource = context.Clienti
                            .Where(C => C.Codice_MacroArea == ddlMacroArea.SelectedValue && C.Ragione_Sociale.StartsWith(strFilter))
                            .OrderBy(C => C.Ragione_Sociale).ToList();
                    }
                    GVClienti.DataBind();
                }
            }
        }
        protected void GVClienti_SelectedIndexChanged(object sender, EventArgs e)
        {
            id_Cliente.Text = GVClienti.SelectedRow.Cells[1].Text;
            lblRagioneSociale.Text = ((Label)GVClienti.SelectedRow.FindControl("lblRagione_Sociale")).Text.ToString();
            //lblRagioneSociale.Text = GVClienti.SelectedRow.Cells[2].Text;
            lblP_Iva.Text = GVClienti.SelectedRow.Cells[3].Text;
            lblComune.Text = GVClienti.SelectedRow.Cells[4].Text;
            lblCAP.Text = GVClienti.SelectedRow.Cells[5].Text;
            lblProvincia.Text = GVClienti.SelectedRow.Cells[6].Text;
            //CercaPrezziNetti();
            GVClienti.DataSource = null;
            GVClienti.DataBind();
        }
        protected void GVClienti_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVClienti.PageIndex = e.NewPageIndex;
            BindClienti((string)ViewState["Ragione_Sociale"]);
            ModalPopupClienti.Show();
        }
        protected void GVClienti_Sorting(object sender, GridViewSortEventArgs e)
        {
            ViewState["Ragione_Sociale"] = ((TextBox)GVClienti.HeaderRow.FindControl("txtRagione_Sociale")).Text.ToString();
            BindClienti(e.SortExpression);
            ModalPopupClienti.Show();
        }
        protected void btnSearchRivenditori_Click(object sender, EventArgs e)
        {
            //btnVisualizzaPrezziNetti.Enabled = false;
            BindRivenditori("");
            ModalPopupRivenditori.Show();
        }
        void BindRivenditori(string SortColumn)
        {
            using (OCCEntities context = new OCCEntities())
            {
                if (context.Rivenditori.Count() > 0)
                {
                    if (SortColumn == "")
                    {
                        //GVRivenditori.DataSource = context.Rivenditori
                        //    .Where(C => C.Codice_MacroArea == ddlMacroArea.SelectedValue)
                        //    .OrderBy(C => C.Ragione_Sociale).ToList();
                        var qryRivenditori = from RM in context.RivenditoriMacroarea
                                             join R in context.Rivenditori on RM.KN equals R.KN
                                             where RM.Codice_MacroArea == ddlMacroArea.SelectedValue
                                             orderby R.Ragione_Sociale
                                             select new { R.Ragione_Sociale, RM.KN, RM.Codice_MacroArea, R.flg_Ricarica };
                        GVRivenditori.DataSource = qryRivenditori.ToList();
                    }
                    else
                    {
                        string strFilter = (string)ViewState["Ragione_Sociale_Riv"];
                        //GVRivenditori.DataSource = context.Rivenditori
                        //    .Where(C => C.Codice_MacroArea == ddlMacroArea.SelectedValue && C.Ragione_Sociale.StartsWith(strFilter))
                        //    .OrderBy(C => C.Ragione_Sociale).ToList();
                        var qryRivenditori = from RM in context.RivenditoriMacroarea
                                             join R in context.Rivenditori on RM.KN equals R.KN
                                             where RM.Codice_MacroArea == ddlMacroArea.SelectedValue && R.Ragione_Sociale.StartsWith(strFilter)
                                             orderby R.Ragione_Sociale
                                             select new { R.Ragione_Sociale, RM.KN, RM.Codice_MacroArea, R.flg_Ricarica };
                        GVRivenditori.DataSource = qryRivenditori.ToList();
                    }
                    GVRivenditori.DataBind();
                }
            }
        }
        protected void GVRivenditori_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblRivenditore.Text = ((Label)GVRivenditori.SelectedRow.FindControl("lblRagione_Sociale_Riv")).Text.ToString();
            lblKNRivenditore.Text = GVRivenditori.SelectedRow.Cells[2].Text;
            lblMCRivenditore.Text = GVRivenditori.SelectedRow.Cells[3].Text;
            chkRicRivenditore.Checked = Convert.ToBoolean(GVRivenditori.SelectedRow.Cells[4].Text);
            //CercaPrezziNetti();
            GVRivenditori.DataSource = null;
            GVRivenditori.DataBind();
        }
        protected void GVRivenditori_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVRivenditori.PageIndex = e.NewPageIndex;
            BindRivenditori((string)ViewState["Ragione_Sociale_Riv"]);
            ModalPopupRivenditori.Show();
        }
        protected void GVRivenditori_Sorting(object sender, GridViewSortEventArgs e)
        {
            ViewState["Ragione_Sociale_Riv"] = ((TextBox)GVRivenditori.HeaderRow.FindControl("txtRagione_Sociale_Riv")).Text.ToString();
            BindRivenditori(e.SortExpression);
            ModalPopupRivenditori.Show();
        }
        protected void PasteToGVPrezziNetti(object sender, EventArgs e)
        {
            string copiedContent = Request.Form[txtCopied.UniqueID];
            ViewState["copiedContent"] = copiedContent;
            BindPrezziNetti();
            txtCopied.Text = "";
        }
        protected void btnVisualizzaPrezziNetti_Click(object sender, EventArgs e)
        {
            ModalPopupPrezziNetti.Show();
        }
        protected void BindPrezziNetti()
        {
            DataTable dt = new DataTable();
            dt.Columns.AddRange(new DataColumn[3] { new DataColumn("Codice_Materiale", typeof(string)),
                    new DataColumn("Prezzo_Netto", typeof(float)),
                    new DataColumn("Ricarica",typeof(float)) });

            string copiedContent = (string)ViewState["copiedContent"];
            foreach (string row in copiedContent.Split('\n'))
            {
                if (!string.IsNullOrEmpty(row))
                {
                    dt.Rows.Add();
                    int i = 0;
                    foreach (string cell in row.Split('\t'))
                    {
                        dt.Rows[dt.Rows.Count - 1][i] = cell;
                        i++;
                    }
                }
            }
            GVPrezziNetti.DataSource = dt;
            GVPrezziNetti.DataBind();
            ModalPopupPrezziNetti.Show();
        }
        protected void GVPrezziNetti_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            GVPrezziNetti.PageIndex = e.NewPageIndex;
            BindPrezziNetti();
            ModalPopupPrezziNetti.Show();
        }

        protected void btnDelGrid_Click(object sender, EventArgs e)
        {
            ViewState["copiedContent"] = "";
            BindPrezziNetti();
            ModalPopupPrezziNetti.Show();
        }

        protected bool ControlloScheda()
        {
            string strErrorMessage = "";
            //idErrorMessage.Text = "";
            if (id_modello.Text == "")
            {
                strErrorMessage = @"Identificativo Modello; ";
            }
            if (lblGid_Agente_1.Text == "")
            {
                strErrorMessage = strErrorMessage + @"Identificativo Agente 1; ";
            }
            if (lblGid_Responsabile.Text == "")
            {
                strErrorMessage = strErrorMessage + @"Identificativo Responsabile; ";
            }
            if (txtValidita_Da.Text == "")
            {
                strErrorMessage = strErrorMessage + @"Data Validità da; ";
            }
            if (txtValidita_A.Text == "")
            {
                strErrorMessage = strErrorMessage + @"Data Validità A;";
            }
            if (id_Cliente.Text == "")
            {
                strErrorMessage = strErrorMessage + @"Identificativo Cliente; ";
            }
            if (lblKNRivenditore.Text == "")
            {
                strErrorMessage = strErrorMessage + @"Identificativo Rivenditore; ";
            }
            if (txtFiliale.Text == "")
            {
                strErrorMessage = strErrorMessage + @"Identificativo Filiale; ";
            }

            if (strErrorMessage == "")
                return true;
            else
            {
                //idErrorMessage.Text = "Risultano non inseriti i seguenti campi obbligatori: " + strErrorMessage;
                return false;
            }
        }

        // Questa funzione è uguale alla creazione del clone, ogni modifica va riportata anche in
        // btnCreaClone_Click() in InsSchede.aspx.cs
        protected void btnSalvaScheda_Click(object sender, EventArgs e)
        {

            if (ControlloScheda())
            {
                using (OCCEntities context = new OCCEntities())
                {
                    using (var dbContextTransaction = context.Database.BeginTransaction())
                    {
                        try
                        {
                            Schede_Intestazione intestazione = new Schede_Intestazione();
                            intestazione.id_modello = Convert.ToInt32(id_modello.Text);
                            intestazione.Codice_MacroArea = ddlMacroArea.SelectedValue;
                            intestazione.Agente1_Gid = lblGid_Agente_1.Text;
                            if (lblGid_Agente_2.Text == "")
                                intestazione.Agente2_Gid = null; // la FK dell'agente 2 è nullable
                            else
                                intestazione.Agente2_Gid = lblGid_Agente_2.Text;
                            intestazione.Responsabile_Gid = lblGid_Responsabile.Text;
                            intestazione.Validita_Da_Mese = txtValidita_Da.Text;
                            intestazione.Validita_A_Mese = txtValidita_A.Text;
                            intestazione.Cliente = Convert.ToInt32(id_Cliente.Text);
                            intestazione.Rivenditore_KN = lblKNRivenditore.Text;
                            intestazione.Filiale = txtFiliale.Text;
                            intestazione.flag_IA = false;
                            intestazione.flag_DT = false;
                            intestazione.stato = ddlStatoScheda.SelectedValue;
                            intestazione.Codice_Cliente = txtCodice_Cliente.Text;
                            intestazione.Rappresentante_Riv = txtRappresentante_Riv.Text;
                            intestazione.Responsabile_Fil_Riv = txtResponsabile_Fil_Riv.Text;
                            intestazione.Firma_Resp_Fil_Riv = txtFirma_Resp_Fil_Riv.Text;
                            intestazione.Creata_il = DateTime.Today;
                            if (ddlStatoScheda.SelectedValue == "I")
                            {
                                intestazione.Inviata_il = DateTime.Today;
                            }
                            if (ddlStatoScheda.SelectedValue == "A")
                            {
                                intestazione.Inviata_il = DateTime.Today;
                                intestazione.Approvata_il = DateTime.Today;
                            }

                            context.Schede_Intestazione.Add(intestazione);

                            context.SaveChanges(); //Salvo prima l'intestazione per ottenere l'id

                            foreach (GridViewRow GVDettaglioRow in GVDettaglio.Rows)
                            {
                                Label lblDescProd = (Label)GVDettaglioRow.FindControl("lblIDescrizione_Prodotto");
                                if (lblDescProd.Text != "Raggruppamento")
                                {
                                    Schede_Dettaglio dettaglio = new Schede_Dettaglio();

                                    dettaglio.id_Intestazione = intestazione.id;

                                    Label lblIFam_SC = (Label)GVDettaglioRow.FindControl("lblIFam_SC");
                                    dettaglio.Codice_Famiglia_Sconti = lblIFam_SC.Text;

                                    TextBox txtSconto = (TextBox)GVDettaglioRow.FindControl("txtSconto");
                                    if (string.IsNullOrEmpty(txtSconto.Text))
                                        dettaglio.Sconto = 0;
                                    else
                                        dettaglio.Sconto = Convert.ToInt32(txtSconto.Text);

                                    TextBox txtExtra = (TextBox)GVDettaglioRow.FindControl("txtExtra");
                                    if (string.IsNullOrEmpty(txtExtra.Text))
                                        dettaglio.Extra = 0;
                                    else
                                        dettaglio.Extra = Convert.ToInt32(txtExtra.Text);

                                    TextBox txtRicarica = (TextBox)GVDettaglioRow.FindControl("txtRicarica");
                                    if (string.IsNullOrEmpty(txtRicarica.Text))
                                        dettaglio.Ricarica = 0;
                                    else
                                        dettaglio.Ricarica = Convert.ToInt32(txtRicarica.Text);

                                    context.Schede_Dettaglio.Add(dettaglio);
                                }
                            }

                            GVPrezziNetti.AllowPaging = false;
                            BindPrezziNetti();
                            foreach (GridViewRow GVPrezziNettiRow in GVPrezziNetti.Rows)
                            {
                                Prezzi_Netti prezzi_netti = new Prezzi_Netti();

                                prezzi_netti.id_Intestazione = intestazione.id;
                                prezzi_netti.Codice_Materiale = GVPrezziNettiRow.Cells[0].Text;
                                prezzi_netti.Prezzo_Netto = Convert.ToInt32(GVPrezziNettiRow.Cells[1].Text);
                                prezzi_netti.Ricarica = Convert.ToInt32(GVPrezziNettiRow.Cells[2].Text);

                                context.Prezzi_Netti.Add(prezzi_netti);

                            }

                            context.SaveChanges();

                            dbContextTransaction.Commit();
                            Session["idUltimaSchedaInserita"] = intestazione.id.ToString();
                            Response.Redirect("MainSchede.aspx");
                        }
                        catch (System.Data.Entity.Validation.DbEntityValidationException ex)
                        {

                            var sb = new System.Text.StringBuilder();
                            foreach (var failure in ex.EntityValidationErrors)
                            {
                                sb.AppendFormat("{0} failed validation\n", failure.Entry.Entity.GetType());
                                foreach (var error in failure.ValidationErrors)
                                {
                                    sb.AppendFormat("- {0} : {1}", error.PropertyName, error.ErrorMessage);
                                    sb.AppendLine();
                                }
                            }
                            dbContextTransaction.Rollback();
                        }
                    }
                }
            }
        }
        protected void ddlMacroArea_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Azzera tutti valori che dipendono dalla macro area
            // Agente 1
            lblAgente1.Text = "";
            lblGid_Agente_1.Text = "";
            // Agente 2
            lblAgente2.Text = "";
            lblGid_Agente_2.Text = "";
            // Responsabile
            lblResponsabile.Text = "";
            lblGid_Responsabile.Text = "";
            // Rivenditore
            lblRivenditore.Text = "";
            lblMCRivenditore.Text = "";
            lblKNRivenditore.Text = "";
            // Cliente
            id_Cliente.Text = "";
            lblRagioneSociale.Text = "";
            lblP_Iva.Text = "";
            lblComune.Text = "";
            lblCAP.Text = "";
            lblProvincia.Text = "";
        }
        protected bool ControllaIntestazione()
        {
            string strErrorMessage = "";
            //idErrorMessage.Text = "";
            if (id_modello.Text == "")
            {
                strErrorMessage = @"Identificativo Modello; ";
            }
            if (lblKNRivenditore.Text == "")
            {
                strErrorMessage = strErrorMessage + @"Identificativo Rivenditore; ";
            }
            if (strErrorMessage == "")
                return true;
            else
            {
                //idErrorMessage.Text = "Risultano non inseriti i seguenti campi obbligatori: " + strErrorMessage;
                return false;
            }
        }
        //protected void CercaPrezziNetti()
        //{
        //    // La tabella Prezzi_Netti ha come chiave Macro Area, Rivenditore, Partita IVA Cliente, Vaidità Da e Validità A
        //    if (id_Cliente.Text != "" && lblKNRivenditore.Text != "" && txtValidita_Da.Text != "" && txtValidita_A.Text != "")
        //    {
        //        using (OCCEntities context = new OCCEntities())
        //        {
        //            string sqlQuery = @"select * from Prezzi_Netti " +
        //                                @"where Codice_MacroArea = '" + ddlMacroArea.SelectedValue + @"' and " +
        //                                @"KN_Rivenditore = '" + lblKNRivenditore.Text + @"' and " +
        //                                @"P_Iva_Cliente = '" + lblP_Iva.Text + @"' and " +
        //                                @"Validita_Da_Mese >= '" + txtValidita_Da.Text + @"' and " +
        //                                @"Validita_A_Mese <= '" + txtValidita_A.Text + @"'";

        //            var query = context.Prezzi_Netti.SqlQuery(sqlQuery).ToList();

        //            if (query.Count > 0) btnVisualizzaPrezziNetti.Enabled = true;
        //        }
        //    }
        //    else
        //        btnVisualizzaPrezziNetti.Enabled = false;
        //}
        //protected void btnVisualizzaPrezziNetti_Click(object sender, EventArgs e)
        //{
        //    BindPrezziNetti();
        //    ModalPopupPrezziNetti.Show();
        //}
        //void BindPrezziNetti()
        //{
        //    using (OCCEntities context = new OCCEntities())
        //    {
        //        if (context.Rivenditori.Count() > 0)
        //        {
        //            string sqlQuery = @"select * from Prezzi_Netti " +
        //                                @"where Codice_MacroArea = '" + ddlMacroArea.SelectedValue + @"' and " +
        //                                @"KN_Rivenditore = '" + lblKNRivenditore.Text + @"' and " +
        //                                @"P_Iva_Cliente = '" + lblP_Iva.Text + @"' and " +
        //                                @"Validita_Da_Mese >= '" + txtValidita_Da.Text + @"' and " +
        //                                @"Validita_A_Mese <= '" + txtValidita_A.Text + @"'";

        //            var query = context.Prezzi_Netti.SqlQuery(sqlQuery).ToList();
        //            GVPrezziNetti.DataSource = query;
        //            GVPrezziNetti.DataBind();
        //        }
        //    }
        //}
        //protected void GVPrezziNetti_PageIndexChanging(object sender, GridViewPageEventArgs e)
        //{
        //    GVPrezziNetti.PageIndex = e.NewPageIndex;
        //    BindPrezziNetti();
        //    ModalPopupRivenditori.Show();
        //}
        protected void btnVisualizzaDettaglio_Click(object sender, EventArgs e)
        {
            if (ControllaIntestazione())
            {
                btnVisualizzaDettaglio.Enabled = false;
                using (OCCEntities context = new OCCEntities())
                {
                    int iid_Modello = Convert.ToInt32(id_modello.Text);

                    string sqlQuery = @"SELECT DISTINCT A.Descrizione, B.Codice_raggruppamento, C.Descrizione_Spiridon, C.Catalogo, C.Descrizione_Prodotto, " +
                                      @"C.Codice  as 'Fam_SC', CASE WHEN (D.Fam_SC IS NULL) THEN '' END as 'Fam_SC_Riv', A.Posizione as 'A_Posizione', " +
                                      @"0 as 'Sconto', 0 as 'Extra', 0 as 'Ricarica', B.Posizione as 'B_Posizione' " +
                                      @"FROM Modelli_Dettaglio B " +
                                      @"JOIN Modelli_Raggruppamento A ON A.Codice = B.Codice_raggruppamento " +
                                      @"JOIN Famiglia_Sconti C on B.Codice_Famiglia_Sconti = C.Codice " +
                                      @"LEFT JOIN Fam_SC_Rivenditore D on C.Codice = D.Codice_Famiglia_Sconti_Siemens " +
                                      @"WHERE B.id_modello=" + iid_Modello +
                                      @" ORDER BY A.Posizione, B.Posizione";

                    var query = context.Database.SqlQuery<retDettaglio>(sqlQuery).ToList();

                    var DTDettaglio = new DataTable();
                    DTDettaglio.Columns.AddRange(new DataColumn[]{ 
                new DataColumn("Descrizione_raggruppamento" , typeof(string)),
                new DataColumn("Codice_raggruppamento" , typeof(string)),
                new DataColumn("Descrizione_Spiridon" , typeof(string)),
                new DataColumn("Catalogo" , typeof(string)),
                new DataColumn("Descrizione_Prodotto" , typeof(string)),
                new DataColumn("Fam_SC" , typeof(string)),
                new DataColumn("Fam_SC_Riv" , typeof(string)),
                new DataColumn("Sconto" , typeof(string)),
                new DataColumn("Extra" , typeof(string)),
                new DataColumn("Ricarica" , typeof(string)),
            });

                    foreach (var item in query)
                    {
                        DataRow dr = DTDettaglio.NewRow();
                        if (tmpRaggruppamento != item.Codice_raggruppamento)
                        {
                            DataRow drRag = DTDettaglio.NewRow();
                            drRag["Descrizione_raggruppamento"] = "";
                            drRag["Codice_raggruppamento"] = "";
                            drRag["Descrizione_Spiridon"] = item.Descrizione; //Descrizione Raggruppamento
                            drRag["Catalogo"] = "";
                            drRag["Descrizione_Prodotto"] = "Raggruppamento";
                            drRag["Fam_SC"] = item.Codice_raggruppamento;
                            drRag["Fam_SC_Riv"] = "";
                            drRag["Sconto"] = "";
                            drRag["Extra"] = "";
                            drRag["Ricarica"] = "";
                            DTDettaglio.Rows.Add(drRag);
                            tmpRaggruppamento = item.Codice_raggruppamento;
                        }
                        dr["Descrizione_raggruppamento"] = item.Descrizione;
                        dr["Codice_raggruppamento"] = item.Codice_raggruppamento;
                        dr["Descrizione_Spiridon"] = item.Descrizione_Spiridon;
                        dr["Catalogo"] = item.Catalogo;
                        if (item.Descrizione_Prodotto.Length > 50)
                            dr["Descrizione_Prodotto"] = item.Descrizione_Prodotto.Substring(0, 50);
                        else
                            dr["Descrizione_Prodotto"] = item.Descrizione_Prodotto;
                        dr["Fam_SC"] = item.Fam_SC;
                        dr["Fam_SC_Riv"] = item.Fam_SC_Riv;
                        dr["Sconto"] = item.Sconto;
                        dr["Extra"] = item.Extra;
                        dr["Ricarica"] = item.Ricarica;
                        DTDettaglio.Rows.Add(dr);
                    }

                    ViewState["dtDettaglio"] = DTDettaglio;
                    GVDettaglio.DataSource = ViewState["dtDettaglio"] as DataTable;
                    GVDettaglio.DataBind();
                }
            }
        }
    }
}