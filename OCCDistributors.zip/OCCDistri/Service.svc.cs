﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Web;
using System.Text;

namespace OCCDist
{
    [ServiceContract(Namespace = "")]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class Service
    {
        // To use HTTP GET, add [WebGet] attribute. (Default ResponseFormat is WebMessageFormat.Json)
        // To create an operation that returns XML,
        //     add [WebGet(ResponseFormat=WebMessageFormat.Xml)],
        //     and include the following line in the operation body:
        //         WebOperationContext.Current.OutgoingResponse.ContentType = "text/xml";
        [OperationContract]
        [WebInvoke(ResponseFormat = WebMessageFormat.Json)]
        public List<string> GetNames(string prefixText)
        {
            OCCEntities context = new OCCEntities();

            var qryUtenti = from U in context.Utenti
                            where U.Cognome.Substring(0, prefixText.Length).ToLower() == prefixText.ToLower()
                            select new { U.Cognome, U.Nome };

            List<string> name = new List<string>();

            foreach (var item in qryUtenti)
            {
                name.Add(item.Cognome.ToString() + " " + item.Nome.ToString());
            }

            return name;
        }
        [OperationContract]
        [WebInvoke(ResponseFormat = WebMessageFormat.Json)]
        public List<string> GetFiliali(string prefixText)
        {
            OCCEntities context = new OCCEntities();

            var qryFiliali = from F in context.Filiali
                             where F.Codice.Substring(0, prefixText.Length).ToLower() == prefixText.ToLower()
                             select new { F.Codice };

            List<string> name = new List<string>();

            foreach (var item in qryFiliali)
            {
                name.Add(item.Codice.ToString());
            }

            return name;
        }
    }
}
