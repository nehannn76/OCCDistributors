﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace OCCDist
{
    public partial class TestGeneric : System.Web.UI.Page
    {
        string SIEMENS_GID = "";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DataTable dt = new DataTable();

                dt.Columns.Add(new DataColumn("KN", typeof(string)));
                dt.Columns.Add(new DataColumn("Ragione_Sociale", typeof(string)));
                dt.Columns.Add(new DataColumn("PartitaIva", typeof(string)));
                dt.Columns.Add(new DataColumn("flg_Ricarica", typeof(string)));

                using (OCCEntities context = new OCCEntities())
                {
                    var query = from R in context.Rivenditori.AsEnumerable()
                                orderby R.Ragione_Sociale
                                select R;

                    foreach (var item in query)
                    {
                        DataRow dr = dt.NewRow();
                        dr["KN"] = item.KN;
                        dr["Ragione_Sociale"] = item.Ragione_Sociale;
                        dr["PartitaIva"] = item.PartitaIva;
                        dr["flg_Ricarica"] = item.flg_Ricarica;
                        dt.Rows.Add(dr);
                    }
                    ViewState["dt"] = dt;
                    BindGrid();
                }
            }
        }
        void BindGrid()
        {
            GVRivenditori.DataSource = ViewState["dt"] as DataTable;
            GVRivenditori.DataBind();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            GVRivenditori.Sort("ragionesociale", SortDirection.Descending);
        }

        protected void chkSegreteria_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void chkAgente_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void chkResponsabile_CheckedChanged(object sender, EventArgs e)
        {

        }

        protected void GVRivenditori_Sorting(object sender, GridViewSortEventArgs e)
        {
            //DataTable dt = ViewState["dt"] as DataTable;
            //var dv = new DataView(dt);
            //dv.Sort = "Ragione_Sociale DESC";
            //dt = dv.ToTable();
            //ViewState["dt"] = dt;
            //BindGrid();
            //BindingSource bindingSource = (BindingSource)GVRivenditori.DataSource;
            //DataTable dt = (DataTable)bindingSource.DataSource; 
            DataTable dt = GetDataTable(GVRivenditori);
            DataView dv = new DataView(dt);
            dv.Sort = "Ragione_Sociale DESC";
            dt = dv.ToTable();
            ViewState["dt"] = dt;
            BindGrid();

        }
        DataTable GetDataTable(GridView gv)
        {
            DataTable dt = new DataTable();

            dt.Columns.Add(new DataColumn("KN", typeof(string)));
            dt.Columns.Add(new DataColumn("Ragione_Sociale", typeof(string)));
            dt.Columns.Add(new DataColumn("PartitaIva", typeof(string)));
            dt.Columns.Add(new DataColumn("flg_Ricarica", typeof(string)));

            foreach (GridViewRow row in gv.Rows)
            {
                DataRow dr = dt.NewRow();

                LinkButton lblKN = (LinkButton)row.FindControl("lblKN");
                dr[0] = lblKN.Text;
                Label lblUCognome = (Label)row.FindControl("lblUCognome");
                dr[1] = lblUCognome.Text;

                dr[2] = row.Cells[2].Text;
                dr[3] = row.Cells[3].Text;
                
                dt.Rows.Add(dr);
            }
            return dt;
        }

        protected void GVRivenditori_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }

        protected void GVRivenditori_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {

        }

        protected void btnDefault_Click(object sender, EventArgs e)
        {

        }
    }
}