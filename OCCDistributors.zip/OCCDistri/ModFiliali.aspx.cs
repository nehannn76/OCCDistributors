﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OCCDist
{
    public partial class ModFiliali : System.Web.UI.Page
    {
        private static string SIEMENS_GID = "";
        private Utilities ut = new Utilities();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SIEMENS_GID = (string)Session["SIEMENS_GID"];
                NomeFiliale.Text = Request.QueryString["NomeFiliale"];
                using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
                {
                    var filiale = context.Filiali.FirstOrDefault(F => F.Codice == NomeFiliale.Text);
                    NomeFiliale.Text = filiale.Codice;
                }
            }
        }
        private bool Controllo()
        {
            string strControllo = "";
            using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
            {
                strControllo = "<font color=red><ul>";

                var qrySchede = context.Schede_Intestazione.FirstOrDefault(S => S.Filiale == NomeFiliale.Text);
                if (qrySchede != null) // esiste almeno una scheda per questa filiale, non si può cancellare
                {
                    strControllo = strControllo + "<li> Rimozione bloccata! La scheda " + qrySchede.id + " è assegnata alla filiale </li>";
                }

                strControllo = strControllo + "</ul></font>";
            }
            if (strControllo == "<font color=red><ul></ul></font>") // nessun impedimento
                return true;
            else
            {
                ErrorMessage.Text = strControllo;
                return false;
            }
        }

        protected void btnDelete_Click(object sender, EventArgs e)
        {
            if (Controllo())
            {
                using (OCCEntities context = new OCCEntities(CurrentEnvironment.DbConnectionString))
                {
                    var filiale = context.Filiali.FirstOrDefault(F => F.Codice == NomeFiliale.Text);
                    context.Filiali.Remove(filiale);
                    context.SaveChanges();

                    ut.InsLog(SIEMENS_GID, "Filiali", 0, "INFO", "Eliminata Filiale: " + filiale.Codice);

                    Response.Redirect("MainFiliali.aspx", false);
                }
            }
        }
    }
}