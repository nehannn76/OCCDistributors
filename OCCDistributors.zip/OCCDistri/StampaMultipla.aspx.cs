﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SelectPdf;
using System.Configuration;

namespace OCCDist
{
    public partial class StampaMultipla : System.Web.UI.Page
    {
        string sNumScheda = string.Empty;

        protected void Page_Load(object sender, EventArgs e)
        {

            sNumScheda = Request.QueryString["id"];

            string UrlStampa = "";

            string Ambiente = ConfigurationManager.AppSettings["Ambiente"];
            switch (Ambiente)
            {
                case "Test":
                    UrlStampa = ConfigurationManager.AppSettings["UrlStampaTest"];
                    break;
                case "Qual":
                    UrlStampa = ConfigurationManager.AppSettings["UrlStampaQual"];
                    break;
                case "Prod":
                    UrlStampa = ConfigurationManager.AppSettings["UrlStampaProd"];
                    break;
            }

            string url = UrlStampa + sNumScheda;
            //string url = "/StampaScheda?idscheda=" + idNumScheda.Text;

            HtmlToPdf converter = new HtmlToPdf();

            // set converter options
            converter.Options.PdfPageSize = PdfPageSize.A4;
            converter.Options.PdfPageOrientation = PdfPageOrientation.Portrait;
            converter.Options.MarginLeft = 10;
            converter.Options.MarginRight = 10;
            converter.Options.MarginTop = 20;
            converter.Options.MarginBottom = 20;
            //converter.Options.MinPageLoadTime = 2;
            converter.Options.MaxPageLoadTime = 60;
            //converter.Options.AutoFitWidth = HtmlToPdfPageFitMode.NoAdjustment;

            // create a new pdf document converting an url
            PdfDocument doc = converter.ConvertUrl(url);

            doc.Save(Response, true, sNumScheda +  ".pdf");

            // close pdf document
            doc.Close();
        }
    }
}